import os
import django
from django.db import models

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()


from main_app.models import Author, Article, Review


def get_authors(search_name=None, search_email=None):

    authors = None
    if search_name is not None and search_email is not None:
        authors = Author.objects.filter(full_name__icontains=search_name, email__icontains=search_email)
    elif search_name is not None:
        authors = Author.objects.filter(full_name__icontains=search_name)
    elif search_email is not None:
        authors = Author.objects.filter(email__icontains=search_email)
    else:
        return ""

    if authors is None:
        return ""

    result = ""
    for author in authors.order_by('-full_name'):
        status = "Banned" if author.is_banned else "Not Banned"
        result += f"Author: {author.full_name}, email: {author.email}, status: {status}\n"

    return result


def get_top_publisher():
    our_authors = Author.objects.annotate(counter_article=models.Count('article')).order_by('-counter_article', 'email')

    if not our_authors.exists():
        return ""

    top_author = our_authors.first()
    number_articles = top_author.article_count if hasattr(top_author, 'counter_article') else 0

    return f"Top Author: {top_author.full_name} with {number_articles} published articles."


def get_top_reviewer():
    our_authors = Author.objects.annotate(counter_review=models.Count('review')).order_by('-counter_review', 'email')

    if not our_authors.exists():
        return ""

    top_reviewer = our_authors.first()
    reviews_number = top_reviewer.review_count if hasattr(top_reviewer, 'counter_review') else 0

    return f"Top Reviewer: {top_reviewer.full_name} with {reviews_number} published reviews."
