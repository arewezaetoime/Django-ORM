import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ready_to_use_django_skeleton.settings")
django.setup()

# Import your models
# Create and check models
# Run and print your queries
